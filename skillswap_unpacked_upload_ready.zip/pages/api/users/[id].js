import users from '../../../data/users.json';

export default function handler(req, res) {
  const { id } = req.query;
  const user = users.find((u) => u.id === id);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  res.status(200).json(user);
}
